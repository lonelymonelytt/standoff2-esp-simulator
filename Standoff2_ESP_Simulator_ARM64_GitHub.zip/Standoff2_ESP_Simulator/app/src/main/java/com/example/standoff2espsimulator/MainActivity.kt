package com.example.standoff2espsimulator

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var preview: PreviewView
    private var boxes = true
    private var names = true
    private var distance = true
    private var radar = true
    private var accent = Color.rgb(70, 220, 160)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 22, 18, 18)
            setBackgroundColor(Color.rgb(12, 17, 24))
        }
        val title = TextView(this).apply {
            text = "STANDOFF 2  •  ESP SIMULATOR"
            setTextColor(Color.WHITE); textSize = 19f; gravity = Gravity.CENTER
            setPadding(0, 4, 0, 6)
        }
        val subtitle = TextView(this).apply {
            text = "DEMO MODE — локальная визуализация, не подключается к игре"
            setTextColor(Color.rgb(150, 166, 180)); textSize = 11f; gravity = Gravity.CENTER
            setPadding(0, 0, 0, 14)
        }
        preview = PreviewView()
        root.addView(title)
        root.addView(subtitle)
        root.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.rgb(23, 31, 42))
        }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(toggle("BOX ESP", boxes) { boxes = it; preview.invalidate() }, weight())
        row1.addView(toggle("NAME ESP", names) { names = it; preview.invalidate() }, weight())
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(toggle("DISTANCE", distance) { distance = it; preview.invalidate() }, weight())
        row2.addView(toggle("RADAR", radar) { radar = it; preview.invalidate() }, weight())
        controls.addView(row1); controls.addView(row2)
        val colorLabel = TextView(this).apply {
            text = "ЦВЕТ ESP"; setTextColor(Color.LTGRAY); textSize = 12f
            setPadding(4, 8, 4, 0)
        }
        controls.addView(colorLabel)
        val colors = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(Color.rgb(70,220,160), Color.rgb(80,170,255), Color.rgb(255,190,70), Color.rgb(255,90,110)).forEachIndexed { i, c ->
            val b = Button(this).apply {
                text = listOf("МЯТНЫЙ", "СИНИЙ", "ЗОЛОТОЙ", "КРАСНЫЙ")[i]
                textSize = 9f; setTextColor(Color.WHITE); setBackgroundColor(c)
                setOnClickListener { accent = c; preview.invalidate() }
            }
            colors.addView(b, LinearLayout.LayoutParams(0, 44, 1f).apply { setMargins(3, 2, 3, 2) })
        }
        controls.addView(colors)
        root.addView(controls)
        setContentView(root)
        preview.updateState { boxes; names; distance; radar; accent }
    }

    private fun weight() = LinearLayout.LayoutParams(0, 44, 1f).apply { setMargins(4, 3, 4, 3) }
    private fun toggle(label: String, initial: Boolean, changed: (Boolean) -> Unit): Switch {
        return Switch(this).apply {
            text = label; textSize = 11f; setTextColor(Color.WHITE)
            isChecked = initial
            setOnCheckedChangeListener { _, checked ->
                changed(checked)
                preview.updateState { boxes; names; distance; radar; accent }
            }
        }
    }

    inner class PreviewView : View(this@MainActivity) {
        private val p = Paint(3)
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val w = width.toFloat(); val h = height.toFloat()
            c.drawColor(Color.rgb(8, 13, 19))
            // stylized training arena background
            p.color = Color.rgb(24, 34, 42); p.strokeWidth = 1f; p.style = Paint.Style.STROKE
            for (i in 1..5) c.drawLine(w*i/6, 0f, w*i/6, h, p)
            for (i in 1..5) c.drawLine(0f, h*i/6, w, h*i/6, p)
            p.style = Paint.Style.FILL; p.color = Color.rgb(44, 58, 65)
            c.drawRoundRect(w*.12f, h*.18f, w*.42f, h*.29f, 8f, 8f, p)
            c.drawRoundRect(w*.58f, h*.58f, w*.88f, h*.70f, 8f, 8f, p)
            c.drawRoundRect(w*.42f, h*.40f, w*.58f, h*.53f, 6f, 6f, p)
            val sample = listOf(
                Triple(.24f,.43f,"BOT_07"), Triple(.72f,.34f,"TRAINING_2"), Triple(.61f,.80f,"BOT_13")
            )
            sample.forEachIndexed { i, item ->
                val x=w*item.first; val y=h*item.second
                p.color = accent; p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f
                if (boxes) c.drawRoundRect(x-25, y-45, x+25, y+45, 4f, 4f, p)
                p.style = Paint.Style.FILL; p.textSize = 12f; p.typeface = android.graphics.Typeface.DEFAULT_BOLD
                if (names) { p.color = Color.WHITE; c.drawText(item.third, x-29, y-53, p) }
                if (distance) { p.color = accent; p.textSize = 10f; c.drawText("${18+i*11} m", x-12, y+59, p) }
                p.color = accent; c.drawCircle(x, y, 3.5f, p)
            }
            if (radar) drawRadar(c, w, h)
            p.color = Color.rgb(190,205,215); p.textSize = 10f; p.typeface = android.graphics.Typeface.DEFAULT
            c.drawText("SIMULATED TRAINING SCENE", 12f, h-12f, p)
        }
        private fun drawRadar(c: Canvas, w: Float, h: Float) {
            val cx=w-66f; val cy=66f
            p.style=Paint.Style.STROKE; p.strokeWidth=1.5f; p.color=accent
            c.drawCircle(cx,cy,48f,p); c.drawCircle(cx,cy,24f,p)
            c.drawLine(cx-48,cy,cx+48,cy,p); c.drawLine(cx,cy-48,cx,cy+48,p)
            p.style=Paint.Style.FILL
            listOf(Pair(-19f,-22f),Pair(23f,-8f),Pair(8f,28f)).forEach {
                p.color=accent; c.drawCircle(cx+it.first,cy+it.second,4f,p)
            }
        }
        fun updateState(block: () -> Unit) { block(); invalidate() }
    }
}
