plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.standoff2espsimulator"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.standoff2espsimulator"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += "arm64-v8a" }
    }
}
