# Standoff 2 ESP Simulator (safe demo)

A standalone Android demo that renders a fictional training scene with sample boxes, nicknames, distance labels and a radar. It does **not** connect to Standoff 2, inspect game memory, track real players, draw over another app, inject code, or bypass anti-cheat.

## Build
- Android Studio with JDK 17 and Android SDK 35: open this folder and build `app`.
- Or push to GitHub. The included Actions workflow builds an ARM64 debug APK on every push to `main`.
- In GitHub: open **Actions** → **Android APK Build** → completed run → download artifact `standoff2-esp-simulator-arm64`.

The APK is a debug build for testing, not a Play Store release.
